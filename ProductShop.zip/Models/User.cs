﻿namespace ProductShop.Models
{
    using ProductShop.Common;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class User
    {
        public User()
        {
            this.ProductsSold = new List<Product>();
            this.ProductsBought = new List<Product>();
        }

        public int Id { get; set; }

        public string FirstName { get; set; }
        
        [MinLength(GlobalConstants.UserLastNameMinLength)]
        public string LastName { get; set; }

        public int? Age { get; set; }

       // [InverseProperty("Seller")]
        public ICollection<Product> ProductsSold { get; set; }
       // [InverseProperty("Buyer")]
        public ICollection<Product> ProductsBought { get; set; }
    }
}