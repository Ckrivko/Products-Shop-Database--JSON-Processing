﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public  class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-MANIFEK\SQLEXPRESS;Database=ProductShop;Integrated Security=True";


    }
}
